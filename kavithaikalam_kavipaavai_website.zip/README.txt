கவிதைக்களம் கவிபாவை குழுமம் – Website
இந்த package ஒரு responsive static website.
index.html ஐ browser-ல் திறக்கலாம் அல்லது hosting-ல் index.html + style.css ஐ upload செய்யலாம்.
பின்னர் புகைப்படங்கள், வீடியோக்கள், சமூக வலைதள இணைப்புகள் போன்றவற்றை எளிதாக சேர்க்கலாம்.
